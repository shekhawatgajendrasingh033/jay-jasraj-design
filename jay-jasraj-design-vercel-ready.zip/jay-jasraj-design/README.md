# JAY JASRAJ DESIGN — website + inquiry backend

```
index.html          the website (React + htm via CDN); the contact form posts to /api/inquiry
api/inquiry.js      serverless function (Node 18+): validate → save → email + WhatsApp
test/               offline tests (mocked services): `node --test`
.env.example        every variable you must set
```

## How an inquiry is handled
1. Server validates and sanitises every field (name, email, phone, project type, message). Phone is required.
2. Spam checks: hidden honeypot field, minimum fill time, 5 inquiries/hour per IP, duplicate detection (same email + message within 10 min, plus a per-form idempotency key).
3. The inquiry is **saved** (Upstash Redis).
4. Email (Resend) and WhatsApp (Cloud API) are sent **independently**. One failing never blocks the other.
5. The visitor sees success only if the inquiry is durably recorded (saved, or delivered to you by at least one channel). Otherwise they see an error, their text stays in the form, and they can retry.
6. Each saved inquiry stores the result of each channel (`status.email`, `status.whatsapp`) so you can see what failed.

## Setup (about 30–60 minutes; WhatsApp approval can take longer)
**1. Hosting.** Deploy this folder to Vercel (free): import the project or run `vercel`. The `api/` folder becomes `/api/inquiry` automatically. Netlify/Cloudflare need small adapter changes.

**2. Storage (required).** Create a free database at upstash.com → Redis → copy the REST URL and REST token into `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`. Inquiries are stored under `inq:<id>`; the list `inquiries` holds the ids (newest first).

**3. Email (Resend).** Create an account at resend.com, add and verify your domain, create an API key → `RESEND_API_KEY`. Set `RESEND_FROM` to an address on that domain. Until a domain is verified, Resend only allows sending to the account owner's own email.

**4. WhatsApp Business Cloud API (Meta).**
1. developers.facebook.com → create an app (type Business) → add the WhatsApp product.
2. Create/link a WhatsApp Business Account (needs a verified Meta Business portfolio for production use).
3. Add a sending phone number. This must be a number that is *not* already registered on the regular WhatsApp app. Copy its **Phone number ID** → `WHATSAPP_PHONE_NUMBER_ID`.
4. Create a permanent token: Business Settings → System Users → add system user → generate token with `whatsapp_business_messaging` and `whatsapp_business_management` → `WHATSAPP_ACCESS_TOKEN`.
5. Create a message template (Category: **Utility**, Language: English) named e.g. `new_website_inquiry` → `WHATSAPP_TEMPLATE_NAME`. Body, with exactly six variables:
```
NEW WEBSITE INQUIRY
JAY JASRAJ DESIGN
Name: {{1}}
Email: {{2}}
Phone: {{3}}
Project Type: {{4}}
Message:
{{5}}
Date: {{6}}
A new project inquiry has been received through your website.
```
6. Wait for Meta to approve the template. Until it is approved, WhatsApp sends will fail (and be logged as failed; email still works).
7. Owner number `+919316129311` is already the default in `.env.example`. Note: WhatsApp requires an approved template for business-initiated messages; free-form text only works inside a 24-hour window after the owner messages the business number.

**5. Environment variables.** Add everything from `.env.example` in Vercel → Settings → Environment Variables, then redeploy.

**6. Test.** Submit the live form once. You should get the email, a WhatsApp message, and a record in Upstash. Then run `node --test` locally for the offline suite.

## Honest limits
- A WhatsApp "accepted" response from Meta means the message was queued, not that the phone received it. Delivery receipts need a webhook (not included).
- Success rule: if storage is down but email or WhatsApp worked, the visitor still sees success because you have the inquiry. If every channel fails, they see an error.
- Rate limit and duplicate protection use Redis. Without Redis they fall back to per-instance memory, which is weaker, and saving fails.
