'use strict';
// Offline tests: all external services (Upstash, Resend, WhatsApp Cloud API) are mocked. Run: node --test
const test = require('node:test');
const assert = require('node:assert');
const handler = require('../api/inquiry.js');

const ENV = {
  UPSTASH_REDIS_REST_URL: 'https://redis.test', UPSTASH_REDIS_REST_TOKEN: 't',
  RESEND_API_KEY: 're_test', OWNER_EMAIL: 'jayjasrajdesign14@gmail.com',
  WHATSAPP_OWNER_NUMBER: '+919316129311', WHATSAPP_ACCESS_TOKEN: 'wa', WHATSAPP_PHONE_NUMBER_ID: '123', WHATSAPP_TEMPLATE_NAME: 'new_website_inquiry'
};
let calls, store, fail;
function setup(over = {}, failures = {}) {
  for (const k of Object.keys(process.env)) if (/^(UPSTASH|RESEND|WHATSAPP|OWNER|ALLOWED)/.test(k)) delete process.env[k];
  Object.assign(process.env, ENV, over);
  calls = { email: [], wa: [] }; store = new Map(); fail = failures; handler._resetMemory();
  global.fetch = async (url, o) => {
    const body = o && o.body ? JSON.parse(o.body) : null, json = (s, b) => ({ ok: s < 400, status: s, json: async () => b });
    if (url.startsWith('https://redis.test')) {
      if (fail.redis) return json(500, { error: 'down' });
      const [c, k, v, nx] = body;
      if (c === 'SET') { if (nx === 'NX' && store.has(k)) return json(200, { result: null }); store.set(k, v); return json(200, { result: 'OK' }); }
      if (c === 'INCR') { const n = (store.get(k) || 0) + 1; store.set(k, n); return json(200, { result: n }); }
      if (c === 'DEL') { store.delete(k); return json(200, { result: 1 }); }
      return json(200, { result: 1 });
    }
    if (url.includes('resend.com')) { calls.email.push(body); return fail.email ? json(500, { message: 'boom' }) : json(200, { id: 'em_1' }); }
    if (url.includes('graph.facebook.com')) { calls.wa.push(body); return fail.wa ? json(400, { error: { message: 'template not approved' } }) : json(200, { messages: [{ id: 'wamid.1' }] }); }
    throw new Error('unexpected url ' + url);
  };
}
const good = (o = {}) => ({ name: 'Asha Patel', email: 'asha@example.com', phone: '+91 98765 43210', projectType: 'Residential', message: 'I want a modern villa.\nThree bedrooms.', startedAt: Date.now() - 20000, idempotencyKey: Math.random().toString(36), ...o });
function run(body, ip = '1.1.1.1', method = 'POST') {
  return new Promise(resolve => {
    const res = { headers: {}, setHeader(k, v) { this.headers[k] = v; }, end(s) { resolve({ code: this.statusCode, body: JSON.parse(s) }); } };
    handler({ method, body, headers: { 'x-forwarded-for': ip } }, res);
  });
}
const quiet = () => { console.error = () => {}; };

test('valid inquiry is saved, emailed and sent to WhatsApp', async () => {
  quiet(); setup();
  const r = await run(good());
  assert.equal(r.code, 200); assert.equal(r.body.ok, true);
  assert.equal(calls.email.length, 1); assert.equal(calls.wa.length, 1);
  const e = calls.email[0];
  assert.equal(e.subject, 'New Project Inquiry – JAY JASRAJ DESIGN'); assert.deepEqual(e.to, ['jayjasrajdesign14@gmail.com']);
  assert.match(e.html, /Reply to Asha/); assert.match(e.html, /mailto:asha@example\.com/); assert.match(e.html, /Received/);
  const p = calls.wa[0].template.components[0].parameters.map(x => x.text);
  assert.equal(calls.wa[0].to, '919316129311'); assert.equal(p[0], 'Asha Patel'); assert.ok(!/\n/.test(p[4]));
  const rec = JSON.parse([...store].find(([k]) => k.startsWith('inq:'))[1]);
  assert.equal(rec.status.saved, true); assert.equal(rec.status.email.ok, true); assert.equal(rec.status.whatsapp.ok, true);
});
test('invalid submissions are rejected with field errors and nothing is sent', async () => {
  quiet(); setup();
  for (const bad of [{ name: '' }, { email: 'nope' }, { phone: 'abc' }, { projectType: 'Hacking' }, { message: 'short' }]) {
    const r = await run(good(bad)); assert.equal(r.code, 400); assert.ok(r.body.fields);
  }
  assert.equal(calls.email.length + calls.wa.length, 0);
});
test('HTML in fields is escaped in the email', async () => {
  quiet(); setup(); await run(good({ message: '<script>alert(1)</script> hello world' }));
  assert.ok(!calls.email[0].html.includes('<script>')); assert.match(calls.email[0].html, /&lt;script&gt;/);
});
test('honeypot and too-fast bots get silent success but nothing is processed', async () => {
  quiet(); setup();
  assert.equal((await run(good({ website: 'http://spam' }))).code, 200);
  assert.equal((await run(good({ startedAt: Date.now() - 500 }))).code, 200);
  assert.equal(calls.email.length + calls.wa.length + store.size, 0);
});
test('duplicate submission is not notified twice', async () => {
  quiet(); setup();
  await run(good({ idempotencyKey: 'k1' })); const r = await run(good({ idempotencyKey: 'k2' }));
  assert.equal(r.body.duplicate, true); assert.equal(calls.email.length, 1); assert.equal(calls.wa.length, 1);
});
test('rate limit blocks the 6th request from one IP', async () => {
  quiet(); setup(); let last;
  for (let i = 0; i < 6; i++) last = await run(good({ email: `u${i}@example.com`, message: 'Message number ' + i + ' for test' }), '9.9.9.9');
  assert.equal(last.code, 429);
});
test('email failure does not stop WhatsApp, and the inquiry stays saved', async () => {
  quiet(); setup({}, { email: true }); const r = await run(good());
  assert.equal(r.code, 200); assert.equal(calls.wa.length, 1);
  assert.equal(JSON.parse([...store].find(([k]) => k.startsWith('inq:'))[1]).status.email.ok, false);
});
test('WhatsApp failure does not stop email, and the inquiry stays saved', async () => {
  quiet(); setup({}, { wa: true }); const r = await run(good());
  assert.equal(r.code, 200); assert.equal(calls.email.length, 1);
});
test('both notifications fail: inquiry is still saved, success is returned honestly', async () => {
  quiet(); setup({}, { email: true, wa: true }); const r = await run(good());
  assert.equal(r.code, 200); assert.ok([...store.keys()].some(k => k.startsWith('inq:')));
});
test('storage down but email works: inquiry is not lost', async () => {
  quiet(); setup({}, { redis: true }); const r = await run(good());
  assert.equal(r.code, 200); assert.equal(calls.email.length, 1);
});
test('everything fails: error is returned (never fake success) and retry is allowed', async () => {
  quiet(); setup({}, { redis: true, email: true, wa: true });
  const r = await run(good({ idempotencyKey: 'same' })); assert.equal(r.code, 503);
});
test('missing credentials are reported, not faked', async () => {
  quiet(); setup({ RESEND_API_KEY: '', WHATSAPP_ACCESS_TOKEN: '' }); const r = await run(good());
  assert.equal(r.code, 200); assert.equal(calls.email.length + calls.wa.length, 0);
  const rec = JSON.parse([...store].find(([k]) => k.startsWith('inq:'))[1]);
  assert.equal(rec.status.email.skipped, true); assert.equal(rec.status.whatsapp.skipped, true);
});
test('non-POST is rejected', async () => { setup(); assert.equal((await run(null, '1.1.1.1', 'GET')).code, 405); });
