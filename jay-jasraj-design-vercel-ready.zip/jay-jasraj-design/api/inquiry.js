'use strict';
/**
 * POST /api/inquiry  — JAY JASRAJ DESIGN contact form backend.
 * Flow: validate -> spam/rate-limit/duplicate checks -> SAVE -> email (Resend) + WhatsApp (Cloud API) independently.
 * All secrets come from environment variables. See .env.example.
 */
const crypto = require('crypto');

const TYPES = ['Residential', 'Commercial', 'Interior Design', 'Modern Architecture', 'Other'];
const RATE_LIMIT = 5;            // submissions per IP per hour
const RATE_WINDOW = 3600;        // seconds
const DUP_WINDOW = 600;          // seconds
const MIN_FILL_MS = 3000;        // forms submitted faster than this are bots
const TIMEOUT_MS = 8000;

const env = (k, d = '') => (process.env[k] || d).trim();
const mem = { rl: new Map(), keys: new Map(), inq: new Map() };   // fallback when Upstash is not configured
const _resetMemory = () => { mem.rl.clear(); mem.keys.clear(); mem.inq.clear(); };

/* ---------- validation & sanitising ---------- */
const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').replace(/\u202E/g, '').trim().slice(0, max);

function validate(b) {
  const d = {
    name: clean(b.name, 80).replace(/\s+/g, ' '),
    email: clean(b.email, 120).toLowerCase(),
    phone: clean(b.phone, 25),
    projectType: clean(b.projectType, 40),
    message: clean(b.message, 2000)
  };
  const errors = {};
  if (d.name.length < 2) errors.name = 'Please enter your full name.';
  if (!/^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]{2,}$/.test(d.email)) errors.email = 'Please enter a valid email address.';
  if (!/^\+?[0-9()\-\s]{7,20}$/.test(d.phone) || d.phone.replace(/\D/g, '').length < 7) errors.phone = 'Please enter a valid phone number.';
  if (!TYPES.includes(d.projectType)) errors.projectType = 'Please choose a project type.';
  if (d.message.length < 10) errors.message = 'Please tell us a little more (at least 10 characters).';
  return { d, errors };
}

/* ---------- storage (Upstash Redis REST, with in-memory fallback for rate limit/dedupe) ---------- */
const hasRedis = () => !!(env('UPSTASH_REDIS_REST_URL') && env('UPSTASH_REDIS_REST_TOKEN'));
async function redis(cmd) {
  const r = await timedFetch(env('UPSTASH_REDIS_REST_URL'), {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + env('UPSTASH_REDIS_REST_TOKEN'), 'Content-Type': 'application/json' },
    body: JSON.stringify(cmd)
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error('redis: ' + (j.error || r.status));
  return j.result;
}
async function incrWithTtl(key, ttl) {
  if (hasRedis()) { const n = await redis(['INCR', key]); if (n === 1) await redis(['EXPIRE', key, ttl]); return n; }
  const now = Date.now(), e = mem.rl.get(key);
  if (!e || e.exp < now) { mem.rl.set(key, { n: 1, exp: now + ttl * 1000 }); return 1; }
  return ++e.n;
}
async function setOnce(key, ttl) {     // true if key was newly set, false if it already existed
  if (hasRedis()) return (await redis(['SET', key, '1', 'NX', 'EX', ttl])) === 'OK';
  const now = Date.now(), e = mem.keys.get(key);
  if (e && e > now) return false;
  mem.keys.set(key, now + ttl * 1000); return true;
}
async function delKey(key) { if (hasRedis()) await redis(['DEL', key]); else mem.keys.delete(key); }
async function saveInquiry(rec) {
  if (hasRedis()) { await redis(['SET', 'inq:' + rec.id, JSON.stringify(rec)]); await redis(['LPUSH', 'inquiries', rec.id]); }
  else throw new Error('storage not configured (set UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN)');
}
async function updateInquiry(rec) { if (hasRedis()) await redis(['SET', 'inq:' + rec.id, JSON.stringify(rec)]); }

function timedFetch(url, opts = {}) {
  const c = new AbortController(), t = setTimeout(() => c.abort(), TIMEOUT_MS);
  return fetch(url, { ...opts, signal: c.signal }).finally(() => clearTimeout(t));
}

/* ---------- message builders ---------- */
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = d => d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' }) + ' IST';

function emailHtml(d, when) {
  const reply = 'mailto:' + encodeURIComponent(d.email).replace('%40', '@') + '?subject=' + encodeURIComponent('Re: Your inquiry – JAY JASRAJ DESIGN') +
    '&body=' + encodeURIComponent('Hi ' + d.name + ',\n\nThank you for contacting JAY JASRAJ DESIGN.\n\n');
  const row = (k, v) => `<tr><td style="padding:14px 0;border-bottom:1px solid #d9d2c5;width:130px;font:600 11px Arial,sans-serif;letter-spacing:.16em;text-transform:uppercase;color:#6f6a62;vertical-align:top">${k}</td><td style="padding:14px 0;border-bottom:1px solid #d9d2c5;font:16px Arial,sans-serif;color:#232220">${v}</td></tr>`;
  return `<!doctype html><html><body style="margin:0;background:#e7e1d6;padding:24px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#f1ede6">
<tr><td style="background:#232220;padding:34px 36px"><div style="font:400 22px Georgia,serif;letter-spacing:.22em;color:#f1ede6">JAY JASRAJ DESIGN</div><div style="font:12px Arial,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#a29c90;margin-top:8px">New Project Inquiry</div></td></tr>
<tr><td style="padding:34px 36px 10px"><div style="font:italic 300 30px Georgia,serif;color:#232220;line-height:1.2">A new inquiry has arrived.</div></td></tr>
<tr><td style="padding:10px 36px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">
${row('Name', esc(d.name))}${row('Email', `<a href="mailto:${esc(d.email)}" style="color:#232220">${esc(d.email)}</a>`)}${row('Phone', `<a href="tel:${esc(d.phone.replace(/[^\d+]/g, ''))}" style="color:#232220">${esc(d.phone)}</a>`)}${row('Project Type', esc(d.projectType))}${row('Received', esc(when))}
${row('Message', `<div style="white-space:pre-wrap;line-height:1.6">${esc(d.message)}</div>`)}</table></td></tr>
<tr><td style="padding:26px 36px 38px"><a href="${esc(reply)}" style="display:inline-block;background:#232220;color:#f1ede6;text-decoration:none;font:500 15px Arial,sans-serif;padding:15px 34px;border-radius:40px">Reply to ${esc(d.name.split(' ')[0])}</a></td></tr>
<tr><td style="padding:18px 36px;border-top:1px solid #d9d2c5;font:12px Arial,sans-serif;color:#6f6a62">Sent automatically from the JAY JASRAJ DESIGN website contact form.</td></tr>
</table></td></tr></table></body></html>`;
}
function emailText(d, when) {
  return `NEW PROJECT INQUIRY – JAY JASRAJ DESIGN\n\nName: ${d.name}\nEmail: ${d.email}\nPhone: ${d.phone}\nProject Type: ${d.projectType}\nReceived: ${when}\n\nMessage:\n${d.message}\n`;
}
// WhatsApp template parameters may not contain newlines, tabs or 4+ consecutive spaces.
const waParam = (s, max) => String(s).replace(/[\r\n\t]+/g, ' | ').replace(/ {4,}/g, '   ').trim().slice(0, max) || '-';

/* ---------- notifiers (each returns {ok, ...} and never throws) ---------- */
async function sendEmail(d, when) {
  const key = env('RESEND_API_KEY'), to = env('OWNER_EMAIL');
  if (!key || !to) return { ok: false, skipped: true, error: 'email not configured (RESEND_API_KEY / OWNER_EMAIL)' };
  try {
    const r = await timedFetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: env('RESEND_FROM', 'JAY JASRAJ DESIGN <onboarding@resend.dev>'), to: [to], reply_to: d.email,
        subject: 'New Project Inquiry – JAY JASRAJ DESIGN', html: emailHtml(d, when), text: emailText(d, when)
      })
    });
    const j = await r.json().catch(() => ({}));
    return r.ok && j.id ? { ok: true, id: j.id } : { ok: false, error: 'resend ' + r.status + ' ' + (j.message || '') };
  } catch (e) { return { ok: false, error: 'resend ' + e.message }; }
}
async function sendWhatsApp(d, when) {
  const token = env('WHATSAPP_ACCESS_TOKEN'), id = env('WHATSAPP_PHONE_NUMBER_ID'), tpl = env('WHATSAPP_TEMPLATE_NAME'), to = env('WHATSAPP_OWNER_NUMBER').replace(/\D/g, '');
  if (!token || !id || !tpl || !to) return { ok: false, skipped: true, error: 'WhatsApp not configured (WHATSAPP_* variables)' };
  const vals = [waParam(d.name, 80), waParam(d.email, 120), waParam(d.phone, 25), waParam(d.projectType, 40), waParam(d.message, 900), waParam(when, 40)];
  try {
    const r = await timedFetch(`https://graph.facebook.com/${env('WHATSAPP_API_VERSION', 'v21.0')}/${id}/messages`, {
      method: 'POST', headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp', to, type: 'template',
        template: { name: tpl, language: { code: env('WHATSAPP_TEMPLATE_LANG', 'en') }, components: [{ type: 'body', parameters: vals.map(text => ({ type: 'text', text })) }] }
      })
    });
    const j = await r.json().catch(() => ({}));
    return r.ok && j.messages ? { ok: true, id: j.messages[0].id } : { ok: false, error: 'whatsapp ' + r.status + ' ' + ((j.error && j.error.message) || '') };
  } catch (e) { return { ok: false, error: 'whatsapp ' + e.message }; }
}

/* ---------- handler ---------- */
const reply = (res, code, body) => { res.statusCode = code; res.setHeader('Content-Type', 'application/json'); res.setHeader('Cache-Control', 'no-store'); res.end(JSON.stringify(body)); };

async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return reply(res, 405, { ok: false, error: 'Method not allowed.' }); }
  const allowed = env('ALLOWED_ORIGIN');
  if (allowed && req.headers.origin && req.headers.origin !== allowed) return reply(res, 403, { ok: false, error: 'Forbidden.' });

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return reply(res, 400, { ok: false, error: 'Invalid request.' });

  // Spam: honeypot and impossibly fast submissions get a silent "success" and are never processed.
  const fastBot = Number(body.startedAt) && Date.now() - Number(body.startedAt) < MIN_FILL_MS;
  if (clean(body.website, 200) || fastBot) return reply(res, 200, { ok: true });

  const { d, errors } = validate(body);
  if (Object.keys(errors).length) return reply(res, 400, { ok: false, error: 'Please check the highlighted fields.', fields: errors });

  const ip = String(req.headers['x-forwarded-for'] || (req.socket && req.socket.remoteAddress) || 'unknown').split(',')[0].trim();
  const claimed = [];
  try {
    if (await incrWithTtl('rl:' + ip, RATE_WINDOW) > RATE_LIMIT) return reply(res, 429, { ok: false, error: 'Too many inquiries. Please try again later or call us.' });
    const idem = clean(body.idempotencyKey, 64);
    const fp = crypto.createHash('sha256').update(d.email + '|' + d.message).digest('hex');
    claimed.push('dup:' + fp);
    let fresh = await setOnce('dup:' + fp, DUP_WINDOW);
    if (fresh && idem) { claimed.push('idem:' + idem); fresh = await setOnce('idem:' + idem, 86400); }
    if (!fresh) return reply(res, 200, { ok: true, duplicate: true });   // already received; do not notify twice
  } catch (e) { console.error('guard error (continuing):', e.message); }

  const now = new Date(), when = fmtDate(now);
  const rec = { id: crypto.randomUUID(), receivedAt: now.toISOString(), ...d, ip, status: { saved: false, email: null, whatsapp: null } };

  let saved = false;
  try { await saveInquiry(rec); saved = true; rec.status.saved = true; } catch (e) { console.error('SAVE FAILED:', e.message); }

  // Email and WhatsApp are independent: one failing never blocks the other.
  const [em, wa] = await Promise.all([sendEmail(d, when), sendWhatsApp(d, when)]);
  rec.status.email = em; rec.status.whatsapp = wa;
  if (!em.ok) console.error('EMAIL FAILED:', em.error);
  if (!wa.ok) console.error('WHATSAPP FAILED:', wa.error);
  if (saved) await updateInquiry(rec).catch(e => console.error('status update failed:', e.message));

  // Success only if the inquiry is durably recorded: stored, or delivered to the owner by at least one channel.
  if (saved || em.ok || wa.ok) return reply(res, 200, { ok: true, id: rec.id });
  for (const k of claimed) await delKey(k).catch(() => {});   // allow the visitor to retry
  console.error('INQUIRY NOT RECORDED:', JSON.stringify({ ...rec, ip: undefined }));   // last-resort copy in server logs
  return reply(res, 503, { ok: false, error: 'We could not send your inquiry right now. Please try again, or contact us by phone or email.' });
}

module.exports = handler;
module.exports.validate = validate;
module.exports._resetMemory = _resetMemory;
